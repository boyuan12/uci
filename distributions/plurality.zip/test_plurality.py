import contextlib
import io
import unittest
from unittest import mock
from plurality import vote, print_winner, main

class TestPlurality(unittest.TestCase):
    
    def _get_stdout(self, tst_str) -> str:
        with mock.patch('sys.stdout', new_callable=io.StringIO) as mock_stdout:
            with mock.patch('builtins.input', side_effect=tst_str):
                main()
            return mock_stdout.getvalue()
        
    def _io_assert(self, inputs: list[str], expected_outputs: list[str]):
        for i in range(len(inputs)):
            with self.assertRaises(StopIteration):
                self._get_stdout(inputs[0:i])
        stdout = self._get_stdout(inputs)
        self.assertListEqual(stdout.split("\n"), expected_outputs)

    def test_vote_successfully(self):
        self.assertTrue(vote("Boyuan", {"Aidan": 0, "Boyuan": 0}))
        
    def test_vote_unsuccessfully(self):
        self.assertFalse(vote("Boyuan", {"Aidan": 0, "Charlie": 0}))
        
    def test_vote_when_no_candidate_is_present(self):
        self.assertFalse(vote("Boyuan", {}))

    def test_print_winner_when_one_candidate_won(self):
        with contextlib.redirect_stdout(io.StringIO()) as output:
            print_winner({"Aidan": 3, "Boyuan": 5})
        self.assertEqual(output.getvalue(), "Boyuan\n")
        
    def test_print_winner_when_multiple_candidate_won(self):
        with contextlib.redirect_stdout(io.StringIO()) as output:
            print_winner({"Aidan": 3, "Boyuan": 1, "Charlie": 3})
        self.assertEqual(output.getvalue(), "Aidan\nCharlie\n")
        
    def test_overall_1(self):
        self._io_assert([
            "3",
            "Aidan",
            "Boyuan",
            "Charlie",
            "5",
            "Aidan",
            "Charlie",
            "Charlie",
            "Boyuan",
            "Boyuan"
        ], [
            "Boyuan",
            "Charlie",
            ""
        ])


    def test_overall_2(self):
        self._io_assert([
            "3",
            "Aidan",
            "Boyuan",
            "Charlie",
            "5",
            "Aidan",
            "Huh?",
            "Charlie",
            "Boyuan",
            "Boyuan"
        ], [
            "Invalid vote, next voter please. ",
            "Boyuan",
            ""
        ])

if __name__ == "__main__":
    unittest.main()

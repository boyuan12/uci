
def main():
    candidates_votes = {}

    num_candidates = int(input("Number of candidates: "))
    for i in range(num_candidates):
        candidate_name = input("Candidate's name: ")
        candidates_votes[candidate_name] = 0
    
    num_voters = int(input("Number of voters: "))
    for i in range(num_voters):
        name = input("Vote: ")
        if not vote(name, candidates_votes):
            print("Invalid vote, next voter please. ")
        else:
            # TODO
            pass

    print_winner()

def vote(name, candidates_votes):
    # TODO
    pass


def print_winner(candidates_votes):
    # TODO
    pass


if __name__ == "__main__":
    main()
